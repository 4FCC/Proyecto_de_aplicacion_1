#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <filesystem>

using namespace std;
namespace fs = std::filesystem;

// Estructura de datos para una canci�n
struct Cancion {
    string nombre;
    string artista;
    string duracion;
};

// Estructura de datos para un CD
struct CD {
    string nombre;
    int cantidadCanciones;
    vector<Cancion> canciones;
};

// Lista para almacenar los CDs le�dos
vector<CD> listaCDs;

// Estructura de datos para la cola de reproducci�n
vector<Cancion> colaReproduccion;

// Funci�n para cargar respaldos desde una carpeta
void CargarRespaldos() {
    string rutaCarpeta;
    cout << "Ingrese la ruta de la carpeta con los respaldos: ";
    cin.ignore();
    getline(cin, rutaCarpeta);

    // Lista para almacenar los nombres de archivos en la carpeta
    vector<string> archivos;

    // Iterar sobre los archivos en la carpeta y agregar sus nombres a la lista
    for (const auto& entry : fs::directory_iterator(rutaCarpeta)) {
        archivos.push_back(entry.path().filename().string());
    }

    // Itera sobre los archivos y procesa cada uno
    for (const string& archivo : archivos) {
        ifstream archivoCD(rutaCarpeta + "/" + archivo);

        if (!archivoCD.is_open()) {
            cout << "Error al abrir el archivo: " << archivo << endl;
            continue;
        }

        // Crear un nuevo CD
        CD cd;
        cd.nombre = archivo; // El nombre del CD es el nombre del archivo
        cd.cantidadCanciones = 0;

        // Leer y procesar las l�neas del archivo
        string linea;
        while (getline(archivoCD, linea)) {
            // Parsear la l�nea y crear una Canci�n
            size_t pos1 = linea.find("||");
            size_t pos2 = linea.rfind("||");

            if (pos1 == string::npos || pos2 == string::npos || pos1 == pos2) {
                cout << "Error en el formato de l�nea en el archivo " << archivo << ": " << linea << endl;
                continue;
            }

            Cancion cancion;
            cancion.nombre = linea.substr(0, pos1);
            cancion.artista = linea.substr(pos1 + 2, pos2 - pos1 - 2);
            cancion.duracion = linea.substr(pos2 + 2);

            // Agregar la Canci�n al CD
            cd.canciones.push_back(cancion);
            cd.cantidadCanciones++;
        }

        // Agregar el CD a la lista de CDs
        listaCDs.push_back(cd);

        archivoCD.close();
    }

    cout << "Respaldos cargados exitosamente." << endl;
}

// Funci�n para agregar una canci�n a la cola de reproducci�n
void AgregarCancionCola() {
    // Verificar si hay CDs disponibles para agregar canciones
    if (listaCDs.empty()) {
        cout << "No hay CDs cargados. Cargue respaldos primero." << endl;
        return;
    }

    // Mostrar la lista de CDs disponibles
    cout << "CDs disponibles para agregar canciones:" << endl;
    for (size_t i = 0; i < listaCDs.size(); ++i) {
        cout << i + 1 << ". " << listaCDs[i].nombre << endl;
    }

    // Pedir al usuario que elija un CD
    int cdSeleccionado;
    cout << "Seleccione un CD: ";
    cin >> cdSeleccionado;

    // Verificar la validez de la selecci�n
    if (cdSeleccionado < 1 || cdSeleccionado > static_cast<int>(listaCDs.size())) {
        cout << "Selecci�n inv�lida. Intente nuevamente." << endl;
        return;
    }

    // Mostrar las canciones del CD seleccionado
    CD& cd = listaCDs[cdSeleccionado - 1];
    cout << "Canciones en el CD \"" << cd.nombre << "\":" << endl;
    for (size_t i = 0; i < cd.canciones.size(); ++i) {
        cout << i + 1 << ". " << cd.canciones[i].nombre << " - " << cd.canciones[i].artista << endl;
    }

    // Pedir al usuario que elija una canci�n
    int cancionSeleccionada;
    cout << "Seleccione una canci�n: ";
    cin >> cancionSeleccionada;

    // Verificar la validez de la selecci�n
    if (cancionSeleccionada < 1 || cancionSeleccionada > static_cast<int>(cd.canciones.size())) {
        cout << "Selecci�n inv�lida. Intente nuevamente." << endl;
        return;
    }

    // Agregar la canci�n seleccionada a la cola de reproducci�n
    Cancion& cancion = cd.canciones[cancionSeleccionada - 1];
    colaReproduccion.push_back(cancion);

    cout << "Canci�n \"" << cancion.nombre << " - " << cancion.artista << "\" agregada a la cola de reproducci�n." << endl;
}

// Funci�n para mostrar la cola de reproducci�n
void MostrarColaReproduccion() {

}

// Funci�n para ordenar la cola de reproducci�n
void OrdenarCola() {

}

// Funci�n para mostrar la reproducci�n actual
void MostrarReproduccionActual() {

}

// Funci�n para reproducir la siguiente canci�n
void ReproducirSiguiente() {

}

int main() {
    int opcion;
    do {
        cout << "\n\tMis playlists\n";
        cout << "1. Cargar Respaldos desde carpeta\n";
        cout << "2. Agregar Cancion a la Cola de Reproduccion\n";
        cout << "3. Ver Cola de Reproduccion\n";
        cout << "4. Ordenar Cola de Reproduccion\n";
        cout << "5. Reproduccion Actual\n";
        cout << "6. Reproducir Siguiente\n";
        cout << "7. Salir\n";
        cout << "Elige una opcion: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            CargarRespaldos();
            break;
        case 2:
            AgregarCancionCola();
            break;
        case 3:
            MostrarColaReproduccion();
            break;
        case 4:
            OrdenarCola();
            break;
        case 5:
            MostrarReproduccionActual();
            break;
        case 6:
            ReproducirSiguiente();
            break;
        case 7:
            cout << "Saliendo del programa..." << endl;
            break;
        default:
            cout << "Opcion invalida. Intente nuevamente." << endl;
            break;
        }
    } while (opcion != 7);

    return 0;
}
