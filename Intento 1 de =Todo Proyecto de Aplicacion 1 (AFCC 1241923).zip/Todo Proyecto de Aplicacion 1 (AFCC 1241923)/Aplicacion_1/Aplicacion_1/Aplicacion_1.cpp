#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int main() {
    int EligeCD;

    cout << "\tMis playlists\n";
    cout << "1. 100 Greatest Hits of All Time.txt\n";
    cout << "2. Abbey Road.txt\n";
    cout << "3. At Night at the Opera.txt\n";
    cout << "4. Back in Black.txt\n";
    cout << "5. Dark Side of The Moon.txt\n";
    cout << "6. ejemplo.txt\n";
    cout << "7. Kid A.txt\n";
    cout << "8. My Beautiful Dark Twisted Fantasy.txt\n";
    cout << "9. Parachutes.txt\n";
    cout << "10. Rumours.txt\n";
    cout << "11. Stankonia.txt\n";
    cout << "12. The Marshall Matters LP.txt\n";
    cout << "13. Thriller.txt\n";
    cout << "14. Vicente Fernandez Para Siempre.txt\n";
    cout << "15. Cerrar el programa\n";

    cout << "Elige el CD que deseas escuchar: ";
    cin >> EligeCD;

    // Seguramente en otros dispositivos haya que cambiar esta ruta.
    string rutaArchivo = "C:\\Users\\andre\\OneDrive\\Documentos\\Proyectos de Progra\\C++\\Todo Proyecto de Aplicacion 1 (AFCC 1241923)\\Lista de CDs\\";

    switch (EligeCD)
    {
    case 1:
    {
        cout << "\nElegiste escuchar: 100 Greatest Hits of All Time.txt\n\n";
        string nombreCD = "100 Greatest Hits of All Time.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 2:
    {
        cout << "\nElegiste escuchar: Abbey Road.txt\n\n";
        string nombreCD = "Abbey Road.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 3:
    {
        cout << "\nElegiste escuchar: At Night at the Opera.txt\n\n";
        string nombreCD = "At Night at the Opera.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 4:
    {
        cout << "\nElegiste escuchar: Back in Black.txt\n\n";
        string nombreCD = "Back in Black.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 5:
    {
        cout << "\nElegiste escuchar: Dark Side of The Moon.txt\n\n";
        string nombreCD = "Dark Side of The Moon.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 6:
    {
        cout << "\nElegiste escuchar: ejemplo.txt\n\n";
        string nombreCD = "ejemplo.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 7:
    {
        cout << "\nElegiste escuchar: Kid A.txt\n\n";
        string nombreCD = "Kid A.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 8:
    {
        cout << "\nElegiste escuchar: My Beautiful Dark Twisted Fantasy.txt\n\n";
        string nombreCD = "My Beautiful Dark Twisted Fantasy.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 9:
    {
        cout << "\nElegiste escuchar: Parachutes.txt\n\n";
        string nombreCD = "Parachutes.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 10:
    {
        cout << "\nElegiste escuchar: Rumours.txt\n\n";
        string nombreCD = "Rumours.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 11:
    {
        cout << "\nElegiste escuchar: Stankonia.txt\n\n";
        string nombreCD = "Stankonia.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 12:
    {
        cout << "\nElegiste escuchar: The Marshall Matters LP.txt\n\n";
        string nombreCD = "The Marshall Matters LP.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 13:
    {
        cout << "\nElegiste escuchar: Thriller.txt\n\n";
        string nombreCD = "Thriller.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 14:
    {
        cout << "\nElegiste escuchar: Vicente Fernandez Para Siempre.txt\n\n";
        string nombreCD = "Vicente Fernandez Para Siempre.txt";
        ifstream archivo(rutaArchivo + nombreCD);
        if (archivo.is_open()) {
            string linea;
            while (getline(archivo, linea)) {
                cout << linea << endl;
            }
            archivo.close();
        }
        else {
            cout << "No se pudo abrir el archivo." << endl;
        }
        break;
    }
    case 15:
        cout << "\nCerrando el programa...\n";
        break;

    default:
        cout << "\nOpción no válida. Selecciona un CD válido o Cerrar el programa." << endl;
        break;
    }
    return 0;
}
